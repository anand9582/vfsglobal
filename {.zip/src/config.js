// src/config.js
const config = {
    baseUrl: process.env.REACT_APP_BASE_URL || 'http://localhost:3000', // Fallback URL
  };
  
  export default config;
  